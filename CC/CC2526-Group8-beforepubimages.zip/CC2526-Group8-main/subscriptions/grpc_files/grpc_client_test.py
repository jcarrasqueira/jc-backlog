import grpc
from subscriptions.grpc_files import subscriptions_pb2
from subscriptions.grpc_files import subscriptions_pb2_grpc

def run():
    with grpc.insecure_channel("localhost:50053") as channel:
        stub = subscriptions_pb2_grpc.SubscriptionServiceStub(channel)
        try:
            response = stub.GetUserSubscription(
                subscriptions_pb2.GetUserSubscriptionRequest(user_id=1)
            )
            print("Response:", response)
        except grpc.RpcError as e:
            print("code:", e.code())
            print("details:", e.details())

if __name__ == "__main__":
    run()