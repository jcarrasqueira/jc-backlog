from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from typing import List, Optional

import hashlib
import jwt
from fastapi import FastAPI, HTTPException, Path, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, field_validator
from sqlalchemy.orm import Session

from config import (
    get_db, UserTable, UserSessionTable,
    JWT_SECRET, JWT_ALGORITHM,
    ACCESS_TOKEN_EXPIRE_MINUTES, REFRESH_TOKEN_EXPIRE_DAYS
)

app = FastAPI(
    title="User Management API",
    version="1.0.0",
    description="REST API for user registration, authentication, and profile management."
)

security = HTTPBearer()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

PASSWORD_REGEX = re.compile(
    r'^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{15,}$'
)

VALID_GENDERS = {"M", "F", "NB", "O"}

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(plain: str, hashed: str) -> bool:
    return hashlib.sha256(plain.encode()).hexdigest() == hashed

def create_access_token(user_id: int, username: str, is_admin: bool) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {
        "sub": str(user_id),
        "username": username,
        "is_admin": is_admin,
        "exp": expire,
        "type": "access"
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def create_refresh_token(user_id: int, username: str) -> tuple[str, datetime]:
    expire = datetime.now(timezone.utc) + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    payload = {"sub": str(user_id), "username": username, "exp": expire, "type": "refresh"}
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token, expire.replace(tzinfo=None)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

def get_current_user_id(credentials: HTTPAuthorizationCredentials = Depends(security)) -> int:
    token = credentials.credentials
    payload = decode_token(token)
    if payload.get("type") != "access":
        raise HTTPException(status_code=401, detail="Invalid token type")
    return int(payload["sub"])

def get_current_admin(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)) -> int:
    token = credentials.credentials
    payload = decode_token(token)
    if payload.get("type") != "access":
        raise HTTPException(status_code=401, detail="Invalid token type")
    if not payload.get("is_admin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return int(payload["sub"])

# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------

class UserRegister(BaseModel):
    username: str = Field(description="Unique username")
    email: str = Field(description="User email address")
    password: str = Field(description="Password (min 15 chars, 1 uppercase, 1 number, 1 special)")
    gender: Optional[str] = Field(default=None, description="Gender: M, F, NB or O")
    age: Optional[int] = Field(default=None, description="Age (optional)")
    termsAccepted: bool = Field(description="Must be true to register")

    @field_validator("password")
    @classmethod
    def validate_password(cls, v):
        if not PASSWORD_REGEX.match(v):
            raise ValueError(
                "Password must be at least 15 characters and contain at least "
                "one uppercase letter, one number, and one special character."
            )
        return v

    @field_validator("gender")
    @classmethod
    def validate_gender(cls, v):
        if v is not None and v not in VALID_GENDERS:
            raise ValueError(f"Gender must be one of: {', '.join(VALID_GENDERS)}")
        return v

    @field_validator("termsAccepted")
    @classmethod
    def validate_terms(cls, v):
        if not v:
            raise ValueError("You must accept the terms and conditions to register.")
        return v


class UserLogin(BaseModel):
    username: str = Field(description="Username or email")
    password: str = Field(description="Password")


class UserUpdate(BaseModel):
    username: Optional[str] = Field(default=None, description="New username")
    gender: Optional[str] = Field(default=None, description="Gender: M, F, NB or O")
    age: Optional[int] = Field(default=None, description="Age")

    @field_validator("gender")
    @classmethod
    def validate_gender(cls, v):
        if v is not None and v not in VALID_GENDERS:
            raise ValueError(f"Gender must be one of: {', '.join(VALID_GENDERS)}")
        return v


class UserResponse(BaseModel):
    user_id: int
    username: str
    email: str
    gender: Optional[str]
    age: Optional[int]
    is_admin: bool = False
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user_id: int
    username: str
    is_admin: bool


# ---------------------------------------------------------------------------
# Routes — Health
# ---------------------------------------------------------------------------

@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Routes — Users
# ---------------------------------------------------------------------------

@app.get("/users", response_model=List[UserResponse], tags=["User Registration"])
def list_users(
    username: Optional[str] = None,
    gender: Optional[str] = None,
    age_min: Optional[int] = None,
    age_max: Optional[int] = None,
    limit: int = 20,
    offset: int = 0,
    db: Session = Depends(get_db),
):
    """List users with optional filters and pagination."""
    try:
        query = db.query(UserTable)

        if username:
            query = query.filter(UserTable.username.ilike(f"%{username}%"))
        if gender:
            if gender not in VALID_GENDERS:
                raise HTTPException(status_code=400, detail=f"Gender must be one of: {', '.join(VALID_GENDERS)}")
            query = query.filter(UserTable.gender == gender)
        if age_min is not None:
            query = query.filter(UserTable.age >= age_min)
        if age_max is not None:
            query = query.filter(UserTable.age <= age_max)

        return query.offset(offset).limit(limit).all()
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing users: {e}")


@app.post("/users", response_model=UserResponse, status_code=201, tags=["User Registration"])
def register_user(user: UserRegister, db: Session = Depends(get_db)):
    """Register a new user."""
    try:
        if db.query(UserTable).filter(UserTable.email == user.email).first():
            raise HTTPException(status_code=409, detail="Email already registered")

        if db.query(UserTable).filter(UserTable.username == user.username).first():
            raise HTTPException(status_code=409, detail="Username already taken")

        new_user = UserTable(
            username=user.username,
            email=user.email,
            password=hash_password(user.password),
            gender=user.gender,
            age=user.age,
            is_admin=False,
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )

        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        return new_user
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error registering user: {e}")
        raise HTTPException(status_code=500, detail=f"Error registering user: {e}")


@app.get("/users/{user_id}", response_model=UserResponse, tags=["User Registration"])
def get_user(user_id: int = Path(description="ID of the user"), db: Session = Depends(get_db)):
    """Get a user by ID."""
    try:
        user = db.query(UserTable).filter(UserTable.user_id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        return user
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving user: {e}")


@app.put("/users/{user_id}", response_model=UserResponse, tags=["User Registration"])
def update_user(
    user_id: int = Path(description="ID of the user"),
    updates: UserUpdate = None,
    db: Session = Depends(get_db),
    current_user_id: int = Depends(get_current_user_id),
):
    """Update a user's profile. Requires authentication."""
    try:
        if current_user_id != user_id:
            raise HTTPException(status_code=403, detail="Cannot update another user's profile")

        user = db.query(UserTable).filter(UserTable.user_id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if updates.username and updates.username != user.username:
            if db.query(UserTable).filter(UserTable.username == updates.username).first():
                raise HTTPException(status_code=409, detail="Username already taken")
            user.username = updates.username

        if updates.gender is not None:
            user.gender = updates.gender
        if updates.age is not None:
            user.age = updates.age

        user.updated_at = datetime.now()
        db.commit()
        db.refresh(user)
        return user
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating user: {e}")


@app.delete("/users/{user_id}", status_code=204, tags=["User Registration"])
def delete_user(
    user_id: int = Path(description="ID of the user"),
    db: Session = Depends(get_db),
    current_user_id: int = Depends(get_current_user_id),
):
    """Delete a user account. Requires authentication."""
    try:
        if current_user_id != user_id:
            raise HTTPException(status_code=403, detail="Cannot delete another user's account")

        user = db.query(UserTable).filter(UserTable.user_id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        db.query(UserSessionTable).filter(UserSessionTable.user_id == user_id).delete()
        db.delete(user)
        db.commit()
        return
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting user: {e}")


@app.patch("/users/{user_id}/admin", response_model=UserResponse, tags=["User Registration"])
def set_admin(
    user_id: int = Path(description="ID of the user"),
    is_admin: bool = True,
    db: Session = Depends(get_db),
    _: int = Depends(get_current_admin),  
):
    """Promote or revoke admin privileges for a user. Requires admin authentication."""
    user = db.query(UserTable).filter(UserTable.user_id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.is_admin = is_admin
    user.updated_at = datetime.now()
    db.commit()
    db.refresh(user)
    return user

# ---------------------------------------------------------------------------
# Routes — Auth
# ---------------------------------------------------------------------------

@app.post("/auth", response_model=TokenResponse, tags=["User Authentication"])
def login(credentials: UserLogin, db: Session = Depends(get_db)):
    """Authenticate a user and return JWT access + refresh tokens."""
    try:
        user = (
            db.query(UserTable)
            .filter(
                (UserTable.username == credentials.username) |
                (UserTable.email == credentials.username)
            )
            .first()
        )

        if not user or not verify_password(credentials.password, user.password):
            raise HTTPException(status_code=401, detail="Invalid credentials")

        access_token = create_access_token(user.user_id, user.username, user.is_admin or False)
        refresh_token, expires_at = create_refresh_token(user.user_id, user.username)

        session = UserSessionTable(
            user_id=user.user_id,
            refresh_token=refresh_token,
            expires_at=expires_at,
            revoked=False,
            created_at=datetime.now(),
        )
        db.add(session)
        db.commit()

        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            user_id=user.user_id,
            username=user.username,
            is_admin=user.is_admin or False,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error during login: {e}")


@app.post("/auth/logout", status_code=200, tags=["User Authentication"])
def logout(
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials = Depends(security),
):
    """Invalidate all active sessions for the current user."""
    try:
        token = credentials.credentials

        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        except jwt.ExpiredSignatureError:
            payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM], options={"verify_exp": False})
        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid token")

        user_id = int(payload["sub"])

        db.query(UserSessionTable).filter(
            UserSessionTable.user_id == user_id,
            UserSessionTable.revoked == False,
        ).update({"revoked": True})
        db.commit()

        return {"message": "Logged out successfully"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error during logout: {e}")


@app.get("/auth/verify", status_code=200, tags=["User Authentication"])
def verify_token(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
):
    """Verify whether the provided Bearer token is valid and not revoked."""
    try:
        token = credentials.credentials
        payload = decode_token(token)
        user_id = int(payload["sub"])

        if payload.get("type") == "refresh":
            session = db.query(UserSessionTable).filter(
                UserSessionTable.user_id == user_id,
                UserSessionTable.refresh_token == token,
                UserSessionTable.revoked == False,
            ).first()
            if not session:
                raise HTTPException(status_code=401, detail="Token has been revoked")

        return {
            "valid": True,
            "user_id": user_id,
            "username": payload.get("username"),
            "is_admin": payload.get("is_admin", False)
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error verifying token: {e}")