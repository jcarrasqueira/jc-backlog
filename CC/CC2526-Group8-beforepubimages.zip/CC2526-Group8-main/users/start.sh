#!/bin/sh
set -e

echo "Starting gRPC server on port 50053..."
PYTHONPATH=/users python /users/grpc/users_server.py &

echo "Starting REST API on port 8001..."
uvicorn users:app --host 0.0.0.0 --port 8001