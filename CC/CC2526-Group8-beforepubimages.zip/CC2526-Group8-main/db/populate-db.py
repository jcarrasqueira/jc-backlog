import os
from pathlib import Path
import psycopg2, hashlib, time
from datetime import datetime

DB_URL = os.getenv("DB_URL")
DATA_DIR = Path("./data")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME")
ADMIN_EMAIL    = os.getenv("ADMIN_EMAIL")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD")

# Load order respecting foreign keys
LOAD_ORDER = [
    "users.csv",
    "user_oauth.csv",
    "user_sessions.csv",
    "movies.csv",
    "genres.csv",
    "movie_genres.csv",
    "movie_cast.csv",
    "ratings.csv",
    "fraud_alerts.csv",
    "badges.csv",
    "user_badges.csv",
    "watchlists.csv",
    "watchlist_movies.csv",
    "subscriptions.csv",
    "user_preferences.csv",
    "user_reference_movies.csv",
    "genre_families.csv",
    "genre_family_members.csv",
    "topics.csv",
    "review_sentiment.csv",
    "rating_topics.csv"
]

SERIAL_TABLES = [
    ("users", "user_id"),
    ("user_sessions", "session_id"),
    ("movies", "movie_id"),
    ("ratings", "rating_id"),
    ("fraud_alerts", "alert_id"),
    ("badges", "badge_id"),
    ("watchlists", "watchlist_id"),
    ("subscriptions", "subscription_id"),
    ("user_preferences", "preference_id"),
    ("user_reference_movies", "reference_id"),
    ("genre_families", "family_id"),
    ("topics", "topic_id"),
    ("review_sentiment", "sentiment_id"),
    ("rating_topics", "rating_topic_id"),
]

def get_conn():
    return psycopg2.connect(DB_URL)

def copy_csv_to_postgres(conn, csv_file):
    table_name = csv_file.replace(".csv", "")
    csv_path = DATA_DIR / csv_file

    print(f"loading {table_name}...")

    with conn.cursor() as cur, open(csv_path, "r", encoding="utf-8") as f:
        header = f.readline().strip()

        copy_sql = f"""
            COPY {table_name} ({header})
            FROM STDIN
            WITH (
                FORMAT CSV,
                DELIMITER ',',
                QUOTE '"',
                ESCAPE '"',
                NULL '',
                HEADER FALSE
            )
        """

        cur.copy_expert(copy_sql, f)

    print(f"loaded {table_name}")

def reset_sequences(conn):
    print("resetting sequences...")
    with conn.cursor() as cur:
        for table, column in SERIAL_TABLES:
            try:
                cur.execute((f"""
                    SELECT setval(
                        pg_get_serial_sequence('{table}', '{column}'),
                        COALESCE((SELECT MAX({column}) FROM {table}), 0) + 1,
                        false
                    )
                """))
                print(f"  reset sequence for {table}.{column}")
            except Exception as e:
                print(f"  skipping {table}.{column}: {e}")
        conn.commit()
    print("sequences reset complete")

def create_admin(conn):
    print("creating admin user if not exists...")
    hashed = hashlib.sha256(ADMIN_PASSWORD.encode()).hexdigest()
    now = datetime.now()

    with conn.cursor() as cur:
        cur.execute("SELECT user_id FROM users WHERE username = %s OR email = %s", 
                    (ADMIN_USERNAME, ADMIN_EMAIL))
        

        if cur.fetchone():
            print(f"  admin '{ADMIN_USERNAME}' already exists, skipping")
        else:
            cur.execute("""
                INSERT INTO users (username, email, password, is_admin, created_at, updated_at)
                VALUES (%s, %s, %s, TRUE, %s, %s)
            """, (ADMIN_USERNAME, ADMIN_EMAIL, hashed, now, now))
   
            conn.commit()
            print(f"  admin '{ADMIN_USERNAME}' created successfully")

def main():
    print("starting db population...")
    conn = get_conn()
    #conn.autocommit = False
    try:
        for csv_file in LOAD_ORDER:
            csv_path = DATA_DIR / csv_file

            if csv_path.exists():
                copy_csv_to_postgres(conn, csv_file)
            else:
                print(f"missing CSV: {csv_file}")

        conn.commit()
        reset_sequences(conn)
        create_admin(conn)
        print("db population complete")

    except Exception as e:
        conn.rollback()
        print("\nError during import:")
        print(e)

    finally:
        conn.close()

if __name__ == "__main__":
    main()