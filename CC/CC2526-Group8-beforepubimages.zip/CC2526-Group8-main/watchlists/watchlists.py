from __future__ import annotations

import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), "grpc"))

from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import List, Optional

import grpc
from fastapi import APIRouter, FastAPI, HTTPException, Path, status
from pydantic import BaseModel, Field

from grpc_files.watchlist_client import WatchlistGrpcClient

# ─────────────────────────────────────────────────────────────────────────────
# gRPC client
# ─────────────────────────────────────────────────────────────────────────────

GRPC_ADDRESS = os.getenv("WATCHLIST_GRPC_URL")
grpc_client = WatchlistGrpcClient(GRPC_ADDRESS)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await grpc_client.start()
    yield
    await grpc_client.close()


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic models
# ─────────────────────────────────────────────────────────────────────────────

class WatchlistMovieOut(BaseModel):
    watchlist_id: int
    movie_id: int
    added_at: Optional[datetime] = None


class WatchlistOut(BaseModel):
    watchlist_id: int
    user_id: str
    title: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class WatchlistDetailOut(WatchlistOut):
    movies: List[WatchlistMovieOut] = []


class WatchlistCreate(BaseModel):
    user_id: str = Field(..., min_length=1, examples=["42"])
    title: str = Field(..., min_length=1, examples=["My Favourites"])


class WatchlistUpdate(BaseModel):
    title: str = Field(..., min_length=1, examples=["Updated Title"])


class AddMovieBody(BaseModel):
    movie_id: int = Field(..., ge=1, description="ID of the movie to add")


# ─────────────────────────────────────────────────────────────────────────────
# gRPC error → HTTP exception
# ─────────────────────────────────────────────────────────────────────────────

_GRPC_TO_HTTP = {
    grpc.StatusCode.NOT_FOUND: status.HTTP_404_NOT_FOUND,
    grpc.StatusCode.INVALID_ARGUMENT: status.HTTP_422_UNPROCESSABLE_ENTITY,
    grpc.StatusCode.ALREADY_EXISTS: status.HTTP_409_CONFLICT,
}


def _raise(exc: grpc.RpcError) -> None:
    code = _GRPC_TO_HTTP.get(exc.code(), status.HTTP_500_INTERNAL_SERVER_ERROR)
    raise HTTPException(status_code=code, detail=exc.details())


# ─────────────────────────────────────────────────────────────────────────────
# Routers
# ─────────────────────────────────────────────────────────────────────────────

watchlists_router = APIRouter(prefix="/watchlists", tags=["Watchlist"])
users_router = APIRouter(prefix="/users", tags=["Watchlist"])


@watchlists_router.get("", response_model=List[WatchlistOut], summary="List all watchlists")
async def list_watchlists():
    try:
        return await grpc_client.list_watchlists()
    except grpc.RpcError as e:
        _raise(e)


@watchlists_router.post("", response_model=WatchlistOut, status_code=201, summary="Create a watchlist")
async def create_watchlist(body: WatchlistCreate):
    try:
        return await grpc_client.create_watchlist(user_id=body.user_id, title=body.title)
    except grpc.RpcError as e:
        _raise(e)


@watchlists_router.get("/{watchlist_id}", response_model=WatchlistDetailOut, summary="Get a watchlist with its movies")
async def get_watchlist(watchlist_id: int = Path(..., ge=1)):
    try:
        return await grpc_client.get_watchlist(watchlist_id)
    except grpc.RpcError as e:
        _raise(e)


@watchlists_router.put("/{watchlist_id}", response_model=WatchlistOut, summary="Update a watchlist title")
async def update_watchlist(body: WatchlistUpdate, watchlist_id: int = Path(..., ge=1)):
    try:
        return await grpc_client.update_watchlist(watchlist_id=watchlist_id, title=body.title)
    except grpc.RpcError as e:
        _raise(e)


@watchlists_router.delete("/{watchlist_id}", status_code=204, summary="Delete a watchlist")
async def delete_watchlist(watchlist_id: int = Path(..., ge=1)):
    try:
        await grpc_client.delete_watchlist(watchlist_id)
    except grpc.RpcError as e:
        _raise(e)


@watchlists_router.post(
    "/{watchlist_id}/movies",
    response_model=WatchlistMovieOut,
    status_code=201,
    summary="Add a movie to a watchlist",
)
async def add_movie(body: AddMovieBody, watchlist_id: int = Path(..., ge=1)):
    try:
        return await grpc_client.add_movie(watchlist_id=watchlist_id, movie_id=body.movie_id)
    except grpc.RpcError as e:
        _raise(e)


@watchlists_router.delete(
    "/{watchlist_id}/movies/{movie_id}",
    status_code=204,
    summary="Remove a movie from a watchlist",
)
async def remove_movie(watchlist_id: int = Path(..., ge=1), movie_id: int = Path(..., ge=1)):
    try:
        await grpc_client.remove_movie(watchlist_id=watchlist_id, movie_id=movie_id)
    except grpc.RpcError as e:
        _raise(e)


@users_router.get("/{user_id}/watchlist", response_model=List[WatchlistOut], summary="List watchlists for a user")
async def get_user_watchlists(user_id: str = Path(..., min_length=1)):
    try:
        return await grpc_client.get_user_watchlists(user_id)
    except grpc.RpcError as e:
        _raise(e)


# ─────────────────────────────────────────────────────────────────────────────
# App
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Watchlists Service",
    version="1.0.0",
    description="REST API backed by the WatchlistService gRPC server.",
    lifespan=lifespan,
)

# ─────────────────────────────────────────────────────────────────────────────
# System Routes
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/health", tags=["System"], summary="Health Check")
async def health_check():
    return {
        "status": "ok",
        "service": "watchlists",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

app.include_router(watchlists_router)
app.include_router(users_router)