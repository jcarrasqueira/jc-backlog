from sqlalchemy.orm import sessionmaker, declarative_base, relationship
from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey, Boolean
from ratings.rating_client import ReviewGrpcClient
from users.users_client import UserGrpcClient
from movies.movies_client import MovieGrpcClient
from datetime import datetime
from dotenv import load_dotenv
import os

load_dotenv()
DB_URL = os.getenv("DB_URL")
REVIEW_GRPC_URL = os.getenv("REVIEW_GRPC_URL")
USERS_GRPC_URL = os.getenv("USERS_GRPC_URL")
MOVIES_GRPC_URL = os.getenv("MOVIES_GRPC_URL")

engine = create_engine(DB_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

review_client = ReviewGrpcClient(target=REVIEW_GRPC_URL)
user_client = UserGrpcClient(target=USERS_GRPC_URL)
movie_client = MovieGrpcClient(target=MOVIES_GRPC_URL)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class UserPreferenceTable(Base):
    __tablename__ = "user_preferences"

    preference_id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.user_id"), nullable=False)
    genre_id = Column(Integer, ForeignKey("genres.genre_id"), nullable=False)
    preference_type = Column(String(10), nullable=False, default="like")
    created_at = Column(DateTime, default=datetime.now())

class User(Base):
    __tablename__ = "users"
    user_id = Column(Integer, primary_key=True)

class Genre(Base):
    __tablename__ = "genres"
    genre_id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)

    movies = relationship("Movie", secondary="movie_genres", back_populates="genres"
)

class MovieGenre(Base):
    __tablename__ = "movie_genres"
    movie_id = Column(Integer, ForeignKey("movies.movie_id"), primary_key=True)
    genre_id = Column(Integer, ForeignKey("genres.genre_id"), primary_key=True)

class UserReferenceMovieTable(Base):
    __tablename__ = "user_reference_movies"

    reference_id = Column(Integer, primary_key=True)
    movie_id = Column(Integer, ForeignKey("movies.movie_id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.user_id"), nullable=False)
    created_at = Column(DateTime, default=datetime.now())

class Movie(Base):
    __tablename__ = "movies"
    movie_id = Column(Integer, primary_key=True)
    movie_title = Column(String(255), nullable=False)
    is_deleted = Column(Boolean)

    genres = relationship("Genre", secondary="movie_genres", back_populates="movies"
)