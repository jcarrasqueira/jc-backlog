from __future__ import annotations

from datetime import datetime
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Path, Query, Depends
from pydantic import BaseModel, Field
from config import Base, get_db, UserPreferenceTable, User, Genre, UserReferenceMovieTable, Movie, review_client, movie_client, user_client
from sqlalchemy.orm import Session 
from contextlib import asynccontextmanager
from ratings.rating_client import ReviewGrpcClient
from users.users_client import UserGrpcClient
from movies.movies_client import MovieGrpcClient

# grpc comunication
@asynccontextmanager
async def lifespan(app: FastAPI):
    await user_client.start()
    await movie_client.start()
    await review_client.start()
    print("Review gRPC client started")
    yield
    await user_client.close()
    await movie_client.close()
    await review_client.close()
    print("Review gRPC client closed")  

def get_review_client():
    return review_client

def get_user_client():
    return user_client

def get_movie_client():
    return movie_client

app = FastAPI(
    title="Recommendation System API",
    version="1.0.0",
    description="REST API for recommendations and user preferences.",
    lifespan=lifespan
)

# Models
class UserPreference(BaseModel):
    user_id: int = Field(unique=True, notnull=True, description="ID of the user")
    genre_id: int = Field(notnull=True, description="ID of the genre")
    preference_type: str = Field(default="like", description="Type of preference, e.g., 'like', 'dislike', 'neutral'")

class CreateUserPreference(BaseModel):
    genre_id: int = Field(notnull=True, description="ID of the genre")
    preference_type: str = Field(default="like", description="Type of preference, e.g., 'like', 'dislike', 'neutral'")

class ReferenceMovie(BaseModel):
    movie_id: int = Field(notnull=True, description="ID of the reference movie")
    user_id: int = Field(unique=True, notnull=True, description="ID of the user")

class Recommendation(BaseModel):
    movie_id: int = Field(notnull=True, description="ID of the recommended movie")
    title: str = Field(notnull=True, description="Title of the recommended movie")
    score: float = Field(notnull=True, description="Score of the recommended movie")

# Routes
@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/users/{user_id}/preferences", response_model=UserPreference)
async def create_user_preference(
    user_id: int = Path(description="ID of the user"),
    preference: CreateUserPreference = None, 
    user_client: UserGrpcClient = Depends(get_user_client),
    movie_client: MovieGrpcClient = Depends(get_movie_client),
    db: Session = Depends(get_db)
):
    try:
        user_exists = await user_client.validate_user(user_id)
        if not user_exists:
            raise HTTPException(status_code=404, detail="User does not exist")
        
        genre_exists = db.query(Genre).filter(Genre.genre_id == preference.genre_id).first() #later make grpc movie get genre
        if not genre_exists:
            raise HTTPException(status_code=404, detail="Genre does not exist")
        
        existing_preference = (
            db.query(UserPreferenceTable)
            .filter(
                UserPreferenceTable.user_id == user_id,
                UserPreferenceTable.genre_id == preference.genre_id
            ).first()
        )

        if existing_preference:
            raise HTTPException(status_code=400, detail="User preference already exists")
        
        new_preference = UserPreferenceTable(
            user_id=user_id,
            genre_id=preference.genre_id,
            preference_type=preference.preference_type
        )
        
        db.add(new_preference)
        db.commit()
        db.refresh(new_preference)
        return new_preference
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating user preference: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating user preference: {e}")

@app.get("/users/{user_id}/preferences", response_model=List[UserPreference])
async def get_user_preferences(
    user_id: int = Path(description="ID of the user"), 
    user_client: UserGrpcClient = Depends(get_user_client),
    db: Session = Depends(get_db)
):
    try:
        user_exists = await user_client.validate_user(user_id)
        if not user_exists:
            raise HTTPException(status_code=404, detail="User does not exist")
        preferences = db.query(UserPreferenceTable).filter(UserPreferenceTable.user_id == user_id).all()
        if not preferences:
            raise HTTPException(status_code=404, detail="User preferences not found")
        return preferences
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving user preferences: {e}")
        raise HTTPException(status_code=500, detail=f"Error retrieving user preferences: {e}")

@app.delete("/users/{user_id}/preferences/{genre_id}")
async def delete_user_preference(
    user_id: int = Path(description="ID of the user"),
    genre_id: int = Path(description="ID of the genre"),
    user_client: UserGrpcClient = Depends(get_user_client),
    db: Session = Depends(get_db)
):
    try:
        user_exists = await user_client.validate_user(user_id)
        if not user_exists:
            raise HTTPException(status_code=404, detail="User does not exist")

        preference = db.query(UserPreferenceTable).filter(
            UserPreferenceTable.user_id == user_id,
            UserPreferenceTable.genre_id == genre_id
        ).first()

        if not preference:
            raise HTTPException(status_code=404, detail="User preference not found")

        db.delete(preference)
        db.commit()
        return {"message": "User preference deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting user preference: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting user preference: {e}")
    
@app.post("/users/{user_id}/reference-movies", response_model=ReferenceMovie)
async def add_reference_movie(
    user_id: int = Path(description="ID of the user"),
    movie_id: int = Query(description="ID of the reference movie"),
    user_client: UserGrpcClient = Depends(get_user_client),
    movie_client: MovieGrpcClient = Depends(get_movie_client),
    db: Session = Depends(get_db)
):
    try:
        user_exists = await user_client.validate_user(user_id)
        movie_exists = await movie_client.validate_movie(movie_id)

        if not user_exists:
            raise HTTPException(status_code=404, detail="User does not exist")
        if not movie_exists:
            raise HTTPException(status_code=404, detail="Movie does not exist")
        
        # latter to validate movie with movie service (grpc calls)
        existing_reference = (
            db.query(UserReferenceMovieTable)
            .filter(
                UserReferenceMovieTable.user_id == user_id,
                UserReferenceMovieTable.movie_id == movie_id
            ).first()
        )

        if existing_reference:
            raise HTTPException(status_code=400, detail="Reference movie already exists for this user")
        
        new_reference = UserReferenceMovieTable(
            user_id=user_id,
            movie_id=movie_id
        )
        
        db.add(new_reference)
        db.commit()
        db.refresh(new_reference)
        return new_reference
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error adding reference movie: {e}")
        raise HTTPException(status_code=500, detail=f"Error adding reference movie: {e}")   
    
@app.get("/users/{user_id}/reference-movies", response_model=List[ReferenceMovie])
async def get_reference_movies(
    user_id: int = Path(description="ID of the user"), 
    user_client: UserGrpcClient = Depends(get_user_client),
    db: Session = Depends(get_db)
):
    try:
        user_exists = user_exists = await user_client.validate_user(user_id)
        if not user_exists:
            raise HTTPException(status_code=404, detail="User does not exist")
        reference_movies = db.query(UserReferenceMovieTable).filter(UserReferenceMovieTable.user_id == user_id).all()
        if not reference_movies:
            raise HTTPException(status_code=404, detail="Reference movies not found for this user")
        return reference_movies
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving reference movies: {e}")
        raise HTTPException(status_code=500, detail=f"Error retrieving reference movies: {e}")

@app.delete("/users/{user_id}/reference-movies/{movie_id}")
async def delete_reference_movie(
    user_id: int = Path(description="ID of the user"),
    movie_id: int = Path(description="ID of the reference movie"),
    user_client: UserGrpcClient = Depends(get_user_client),
    movie_client: MovieGrpcClient = Depends(get_movie_client),
    db: Session = Depends(get_db)
):
    try:
        user_exists = await user_client.validate_user(user_id)
        movie_exists = await movie_client.validate_movie(movie_id)

        if not user_exists:
            raise HTTPException(status_code=404, detail="User does not exist")
        if not movie_exists:
            raise HTTPException(status_code=404, detail="Movie does not exist")

        reference_movie = db.query(UserReferenceMovieTable).filter(
            UserReferenceMovieTable.user_id == user_id,
            UserReferenceMovieTable.movie_id == movie_id
        ).first()

        if not reference_movie:
            raise HTTPException(status_code=404, detail="Reference movie not found for this user")

        db.delete(reference_movie)
        db.commit()
        return {"message": "Reference movie deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting reference movie: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting reference movie: {e}")     

""" only viable if movies services add avg_rating
@app.get("/recommendations/{user_id}", response_model=List[Recommendation])
async def get_recommendations(
    user_id: int,
    db: Session = Depends(get_db),
    user_client: UserGrpcClient = Depends(get_user_client),
    movie_client: MovieGrpcClient = Depends(get_movie_client),
    review: ReviewGrpcClient = Depends(get_review_client),
):
    user_exists = await user_client.validate_user(user_id)
    if not user_exists:
        raise HTTPException(status_code=404, detail="User does not exist")
    
    # positive ratings
    ratings = await review.get_user_ratings(user_id)
    ratings = [rating for rating in ratings if rating.rating >= 3.0]
    rated_movie_ids = [rating.movie_id for rating in ratings]
    
    ref_movies = db.query(UserReferenceMovieTable).filter(UserReferenceMovieTable.user_id == user_id).all()
    ref_movie_ids = [ref_movie.movie_id for ref_movie in ref_movies]
    
    movies_ids = list(set(rated_movie_ids + ref_movie_ids))
    movies = await movie_client.get_movies_batch(movies_ids)
    movies_lookup = {m.movie_id: m for m in movies}

    user_prefs = db.query(UserPreferenceTable).filter(UserPreferenceTable.user_id == user_id).all()
    genre_pref = {}
    
    for r in ratings:
        movie = movies_lookup.get(r.movie_id)
        if movie:
            for g in movie.genres:
                genre_pref[g.name] = genre_pref.get(g.name, 0) + float(r.rating)    
    
    for ref_id in ref_movie_ids:
        movie = movies_lookup.get(ref_id)
        if movie:
            for g in m.genres:
                genre_pref[g.name] = genre_pref.get(g.name, 0) + 1.5
    
    for p in user_prefs:
        genre = db.query(Genre).filter(Genre.genre_id == p.genre_id).first()
        if not genre:
            continue

        if p.preference_type == "like":
            genre_pref[genre.name] = genre_pref.get(genre.name, 0) + 2.0
        elif p.preference_type == "dislike":
            genre_pref[genre.name] = genre_pref.get(genre.name, 0) - 2.0
    
    if not genre_pref:
        return []
    
    candidates_movies = await movie_client.search_movies(limit=100)

    scored = []
    for m in candidates_movies:
        if m.movie_id not in movies_ids:
            continue
        score = sum(genre_pref.get(g.name, 0.0) for g in m.genres)
        if score > 0:
                scored.append(
                    Recommendation(
                        movie_id=m.movie_id,
                        title=m.movie_title,
                        score=float(score)
                    )
                )

    # returns top 5
    scored.sort(key=lambda x: x[0], reverse=True)
    top = [item for item in scored if item[0] > 0][:5]

    return [
        Recommendation(
            movie_id=m.movie_id,
            title=m.movie_title,
            score=float(score)
        )
        for score, m in top
    ]
"""
