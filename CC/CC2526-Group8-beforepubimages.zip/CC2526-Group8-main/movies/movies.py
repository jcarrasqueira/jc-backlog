from __future__ import annotations

from typing import List, Optional

from fastapi import FastAPI, HTTPException, Path, Depends, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, field_validator
from sqlalchemy.orm import Session

from config import (
    get_db, MovieTable, GenreTable, MovieGenreTable, MovieCastTable,
    JWT_SECRET, JWT_ALGORITHM
)
import jwt

app = FastAPI(
    title="Movie Catalog API",
    version="1.0.0",
    description="REST API for movie catalog management, search, and retrieval."
)

security = HTTPBearer()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

def get_current_user_id(credentials: HTTPAuthorizationCredentials = Depends(security)) -> int:
    token = credentials.credentials
    payload = decode_token(token)
    if payload.get("type") != "access":
        raise HTTPException(status_code=401, detail="Invalid token type")
    return int(payload["sub"])

def require_admin(credentials: HTTPAuthorizationCredentials = Depends(security)) -> int:
    """Dependency: requires the user to be an admin."""
    token = credentials.credentials
    payload = decode_token(token)
    if payload.get("type") != "access":
        raise HTTPException(status_code=401, detail="Invalid token type")
    if not payload.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Admin access required")
    return int(payload["sub"])

def get_movie_genres(movie_id: int, db: Session) -> List[str]:
    """Helper to fetch genre names for a movie."""
    genres = db.query(GenreTable.name)\
        .join(MovieGenreTable, GenreTable.genre_id == MovieGenreTable.genre_id)\
        .filter(MovieGenreTable.movie_id == movie_id)\
        .all()
    return [g[0] for g in genres]

def get_movie_cast(movie_id: int, db: Session) -> List[dict]:
    """Helper to fetch cast for a movie."""
    cast = db.query(MovieCastTable)\
        .filter(MovieCastTable.movie_id == movie_id)\
        .all()
    return [{"cast_id": c.cast_id, "cast_name": c.cast_name, "role": c.role} for c in cast]

def build_movie_response(movie: MovieTable, db: Session) -> "MovieResponse":
    return MovieResponse(
        movie_id=movie.movie_id,
        movie_title=movie.movie_title,
        description=movie.description,
        imdb_url=movie.imdb_url,
        release_year=movie.release_year,
        runtime=movie.runtime,
        parental_rating=movie.parental_rating,
        poster_url=movie.poster_url,
        genres=get_movie_genres(movie.movie_id, db),
        cast=get_movie_cast(movie.movie_id, db),
        is_deleted=movie.is_deleted
    )

# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class CastMemberCreate(BaseModel):
    cast_name: str = Field(description="Name of the cast member")
    role: Optional[str] = Field(default=None, description="Role of the cast member")

class CastMemberResponse(BaseModel):
    cast_id: int
    cast_name: str
    role: Optional[str]

    class Config:
        from_attributes = True

class MovieCreate(BaseModel):
    movie_title: str = Field(description="Movie title")
    description: Optional[str] = Field(default=None, description="Movie description/synopsis")
    imdb_url: Optional[str] = Field(default=None, description="IMDb URL")
    release_year: int = Field(description="Release year (>= 1874)")
    runtime: Optional[int] = Field(default=None, description="Runtime in minutes")
    parental_rating: Optional[str] = Field(default=None, description="Parental rating (e.g., PG-13)")
    poster_url: Optional[str] = Field(default=None, description="Poster URL")
    genres: Optional[List[str]] = Field(default=None, description="List of genre names")

    @field_validator("release_year")
    @classmethod
    def validate_release_year(cls, v):
        if v < 1874:
            raise ValueError("Release year must be >= 1874")
        return v

    @field_validator("runtime")
    @classmethod
    def validate_runtime(cls, v):
        if v is not None and v <= 0:
            raise ValueError("Runtime must be greater than 0")
        return v


class MovieUpdate(BaseModel):
    movie_title: Optional[str] = Field(default=None, description="New movie title")
    description: Optional[str] = Field(default=None, description="Movie description")
    imdb_url: Optional[str] = Field(default=None, description="IMDb URL")
    release_year: Optional[int] = Field(default=None, description="Release year")
    runtime: Optional[int] = Field(default=None, description="Runtime in minutes")
    parental_rating: Optional[str] = Field(default=None, description="Parental rating")
    poster_url: Optional[str] = Field(default=None, description="Poster URL")
    genres: Optional[List[str]] = Field(default=None, description="List of genre names")

    @field_validator("release_year")
    @classmethod
    def validate_release_year(cls, v):
        if v is not None and v < 1874:
            raise ValueError("Release year must be >= 1874")
        return v

    @field_validator("runtime")
    @classmethod
    def validate_runtime(cls, v):
        if v is not None and v <= 0:
            raise ValueError("Runtime must be greater than 0")
        return v


class MovieResponse(BaseModel):
    movie_id: int
    movie_title: str
    description: Optional[str]
    imdb_url: Optional[str]
    release_year: int
    runtime: Optional[int]
    parental_rating: Optional[str]
    poster_url: Optional[str]
    genres: List[str] = []
    cast: List[CastMemberResponse] = []
    is_deleted: bool = False

    class Config:
        from_attributes = True

class GenreResponse(BaseModel):
    genre_id: int
    name: str

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# Routes — Health
# ---------------------------------------------------------------------------

@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}

# ---------------------------------------------------------------------------
# Routes — Movies
# ---------------------------------------------------------------------------

@app.get("/movies", response_model=List[MovieResponse], tags=["Movies"])
def list_movies(
    genre: Optional[str] = Query(default=None, description="Filter by genre name"),
    release_year: Optional[int] = Query(default=None, description="Filter by release year"),
    title: Optional[str] = Query(default=None, description="Filter by title (partial match)"),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
):
    """List movies with optional filters and pagination. Only returns non-deleted movies."""
    try:
        query = db.query(MovieTable).filter(MovieTable.is_deleted == False)

        if title:
            query = query.filter(MovieTable.movie_title.ilike(f"%{title}%"))
        if release_year is not None:
            query = query.filter(MovieTable.release_year == release_year)
        if genre:
            query = query.join(MovieGenreTable, MovieTable.movie_id == MovieGenreTable.movie_id)\
                         .join(GenreTable, MovieGenreTable.genre_id == GenreTable.genre_id)\
                         .filter(GenreTable.name.ilike(f"%{genre}%"))

        movies = query.offset(offset).limit(limit).all()
        return [build_movie_response(m, db) for m in movies]
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing movies: {e}")


@app.post("/movies", response_model=MovieResponse, status_code=201, tags=["Movies"])
def create_movie(
    movie: MovieCreate,
    db: Session = Depends(get_db),
    _: int = Depends(require_admin),
):
    """Create a new movie. Requires admin."""
    try:
        new_movie = MovieTable(
            movie_title=movie.movie_title,
            description=movie.description,
            imdb_url=movie.imdb_url,
            release_year=movie.release_year,
            runtime=movie.runtime,
            parental_rating=movie.parental_rating,
            poster_url=movie.poster_url,
            is_deleted=False,
        )
        db.add(new_movie)
        db.flush()

        if movie.genres:
            for genre_name in movie.genres:
                genre = db.query(GenreTable).filter(GenreTable.name == genre_name).first()
                if genre:
                    db.add(MovieGenreTable(movie_id=new_movie.movie_id, genre_id=genre.genre_id))

        db.commit()
        db.refresh(new_movie)
        return build_movie_response(new_movie, db)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error creating movie: {e}")


@app.get("/movies/{movie_id}", response_model=MovieResponse, tags=["Movies"])
def get_movie(
    movie_id: int = Path(description="ID of the movie"),
    db: Session = Depends(get_db)
):
    """Get a movie by ID."""
    try:
        movie = db.query(MovieTable).filter(
            MovieTable.movie_id == movie_id,
            MovieTable.is_deleted == False
        ).first()
        if not movie:
            raise HTTPException(status_code=404, detail="Movie not found")
        return build_movie_response(movie, db)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving movie: {e}")


@app.put("/movies/{movie_id}", response_model=MovieResponse, tags=["Movies"])
def update_movie(
    movie_id: int = Path(description="ID of the movie"),
    updates: MovieUpdate = None,
    db: Session = Depends(get_db),
    _: int = Depends(require_admin),
):
    """Update a movie. Requires admin."""
    try:
        movie = db.query(MovieTable).filter(
            MovieTable.movie_id == movie_id,
            MovieTable.is_deleted == False
        ).first()
        if not movie:
            raise HTTPException(status_code=404, detail="Movie not found")

        if updates.movie_title is not None:
            movie.movie_title = updates.movie_title
        if updates.description is not None:
            movie.description = updates.description
        if updates.imdb_url is not None:
            movie.imdb_url = updates.imdb_url
        if updates.release_year is not None:
            movie.release_year = updates.release_year
        if updates.runtime is not None:
            movie.runtime = updates.runtime
        if updates.parental_rating is not None:
            movie.parental_rating = updates.parental_rating
        if updates.poster_url is not None:
            movie.poster_url = updates.poster_url

        if updates.genres is not None:
            db.query(MovieGenreTable).filter(MovieGenreTable.movie_id == movie_id).delete()
            for genre_name in updates.genres:
                genre = db.query(GenreTable).filter(GenreTable.name == genre_name).first()
                if genre:
                    db.add(MovieGenreTable(movie_id=movie_id, genre_id=genre.genre_id))

        db.commit()
        db.refresh(movie)
        return build_movie_response(movie, db)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error updating movie: {e}")


@app.delete("/movies/{movie_id}", status_code=204, tags=["Movies"])
def delete_movie(
    movie_id: int = Path(description="ID of the movie"),
    db: Session = Depends(get_db),
    _: int = Depends(require_admin),
):
    """Soft delete a movie. Requires admin."""
    try:
        movie = db.query(MovieTable).filter(MovieTable.movie_id == movie_id).first()
        if not movie:
            raise HTTPException(status_code=404, detail="Movie not found")
        movie.is_deleted = True
        db.commit()
        return
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting movie: {e}")


# ---------------------------------------------------------------------------
# Routes — Genres
# ---------------------------------------------------------------------------

@app.get("/genres", response_model=List[GenreResponse], tags=["Genres"])
def list_genres(db: Session = Depends(get_db)):
    """List all available genres."""
    try:
        return db.query(GenreTable).order_by(GenreTable.name).all()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error listing genres: {e}")


# ---------------------------------------------------------------------------
# Routes — Cast
# ---------------------------------------------------------------------------

@app.get("/movies/{movie_id}/cast", response_model=List[CastMemberResponse], tags=["Cast"])
def get_cast(
    movie_id: int = Path(description="ID of the movie"),
    db: Session = Depends(get_db)
):
    """Get the cast of a movie."""
    try:
        movie = db.query(MovieTable).filter(
            MovieTable.movie_id == movie_id,
            MovieTable.is_deleted == False
        ).first()
        if not movie:
            raise HTTPException(status_code=404, detail="Movie not found")

        return db.query(MovieCastTable).filter(MovieCastTable.movie_id == movie_id).all()
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving cast: {e}")


@app.post("/movies/{movie_id}/cast", response_model=CastMemberResponse, status_code=201, tags=["Cast"])
def add_cast_member(
    movie_id: int = Path(description="ID of the movie"),
    cast_member: CastMemberCreate = None,
    db: Session = Depends(get_db),
    _: int = Depends(require_admin),
):
    """Add a cast member to a movie. Requires admin."""
    try:
        movie = db.query(MovieTable).filter(
            MovieTable.movie_id == movie_id,
            MovieTable.is_deleted == False
        ).first()
        if not movie:
            raise HTTPException(status_code=404, detail="Movie not found")

        new_cast = MovieCastTable(
            movie_id=movie_id,
            cast_name=cast_member.cast_name,
            role=cast_member.role
        )
        db.add(new_cast)
        db.commit()
        db.refresh(new_cast)
        return new_cast
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error adding cast member: {e}")


@app.delete("/movies/{movie_id}/cast/{cast_id}", status_code=204, tags=["Cast"])
def remove_cast_member(
    movie_id: int = Path(description="ID of the movie"),
    cast_id: int = Path(description="ID of the cast member"),
    db: Session = Depends(get_db),
    _: int = Depends(require_admin),
):
    """Remove a cast member from a movie. Requires admin."""
    try:
        cast = db.query(MovieCastTable).filter(
            MovieCastTable.cast_id == cast_id,
            MovieCastTable.movie_id == movie_id
        ).first()
        if not cast:
            raise HTTPException(status_code=404, detail="Cast member not found")

        db.delete(cast)
        db.commit()
        return
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error removing cast member: {e}")