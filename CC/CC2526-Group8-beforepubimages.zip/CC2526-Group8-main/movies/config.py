from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Boolean, Text
from dotenv import load_dotenv
import os

load_dotenv()
DB_URL = os.getenv("DB_URL")
JWT_SECRET = os.getenv("JWT_SECRET", "changeme-super-secret")
JWT_ALGORITHM = "HS256"

engine = create_engine(DB_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class MovieTable(Base):
    __tablename__ = "movies"

    movie_id = Column(Integer, primary_key=True, autoincrement=True)
    movie_title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    imdb_url = Column(Text, nullable=True)
    release_year = Column(Integer, nullable=False)
    runtime = Column(Integer, nullable=True)
    parental_rating = Column(String(20), nullable=True)
    poster_url = Column(Text, nullable=True)
    is_deleted = Column(Boolean, default=False)


class GenreTable(Base):
    __tablename__ = "genres"

    genre_id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), unique=True, nullable=False)

class MovieGenreTable(Base):
    __tablename__ = "movie_genres"

    movie_id = Column(Integer, ForeignKey("movies.movie_id"), primary_key=True)
    genre_id = Column(Integer, ForeignKey("genres.genre_id"), primary_key=True)

class MovieCastTable(Base):
    __tablename__ = "movie_cast"

    cast_id = Column(Integer, primary_key=True, autoincrement=True)
    movie_id = Column(Integer, ForeignKey("movies.movie_id"), nullable=False)
    cast_name = Column(String(255), nullable=False)
    role = Column(String(100), nullable=True)