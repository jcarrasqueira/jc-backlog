from __future__ import annotations

from datetime import datetime
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Path, Query, Depends, BackgroundTasks
from pydantic import BaseModel, Field
from config import get_db, RatingTable, user_client, movie_client, Movie
from sqlalchemy import func
from sqlalchemy.orm import Session
from contextlib import asynccontextmanager
from users.users_client import UserGrpcClient
from movies.movies_client import MovieGrpcClient

# grpc comunication
@asynccontextmanager
async def lifespan(app: FastAPI):
    await user_client.start()
    await movie_client.start()
    print("Review gRPC client started")
    yield
    await user_client.close()
    await movie_client.close()
    print("Review gRPC client closed")  

def get_user_client():
    return user_client

def get_movie_client():
    return movie_client

app = FastAPI(
    title="Review System API",
    version="1.0.0",
    description="An API for managing movie ratings, allowing users to submit ratings and retrieve them based on various criteria.",
    lifespan=lifespan
)

# Models
class Rating(BaseModel):
    rating_id: int = Field(unique=True, notnull=True, description="Unique identifier for the rating")
    user_id: int = Field(unique=True, notnull=True, description="Unique identifier for the user who provided the rating")
    movie_id: int = Field(unique=True, notnull=True, description="Unique identifier for the movie being rated")
    rating: float = Field(notnull=True, ge=1.0, le=5.0, description="Rating value between 1 and 5")
    review: Optional[str] = Field(None, description="Optional text review accompanying the rating")
    created_at: datetime = Field(default_factory=datetime.now(), description="Timestamp of when the rating was provided")
    updated_at: datetime = Field(default_factory=datetime.now(), description="Timestamp of the last update to the rating")
    tag: Optional[str] = Field(None, description="Optional list of tags associated with the rating")

    class Config:
        from_attributes = True

class RatingCreate(BaseModel):
    user_id: int = Field(unique=True, notnull=True, description="Unique identifier for the user who provided the rating")
    movie_id: int = Field(unique=True, notnull=True, description="Unique identifier for the movie being rated")
    rating: float = Field(notnull=True, ge=0.0, le=5.0, description="Rating value between 1 and 5")
    review: Optional[str] = Field(None, description="Optional text review accompanying the rating")
    tag: Optional[str] = Field(None, description="Optional tag associated with the rating")

class UpdateRating(BaseModel):
    rating: Optional[float] = Field(None, ge=0.0, le=5.0, description="Updated rating value between 1 and 5")
    review: Optional[str] = Field(None, description="Updated text review accompanying the rating")
    tag: Optional[str] = Field(None, description="Updated tag associated with the rating")

class MovieRating(BaseModel):
    user_id: int = Field(unique=True, notnull=True, description="Unique identifier for the user who provided the rating")
    rating: float = Field(notnull=True, ge=1.0, le=5.0, description="Rating value between 1 and 5")
    review: Optional[str] = Field(None, description="Optional text review accompanying the rating")
    tag: Optional[str] = Field(None, description="Optional tag associated with the rating")

# Routes
@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/ratings", response_model=Rating, status_code=201)
async def create_rating(
    rating_create: RatingCreate, 
    user_client: UserGrpcClient = Depends(get_user_client),
    movie_client: MovieGrpcClient = Depends(get_movie_client),
    background_tasks: BackgroundTasks = None,
    db: Session = Depends(get_db)
):    
    try:
        query = db.query(RatingTable)
        rating_exists = (query
                        .filter(RatingTable.user_id == rating_create.user_id, 
                                RatingTable.movie_id == rating_create.movie_id,
                                RatingTable.is_quarantined == False)         
                        .first())
        
        if rating_exists:
            update_rating = rating_create.model_dump(exclude_unset=True)

            if not update_rating:
                raise HTTPException(status_code=422, detail="No fields provided for update")

            for field, value in update_rating.items():
                setattr(rating_exists, field, value)
            
            rating_exists.updated_at = datetime.now()
            
            db.commit()
            db.refresh(rating_exists)
            background_tasks.add_task(calculate_movie_avg, rating_create.movie_id, get_db)
            return rating_exists

        user_exists = await user_client.validate_user(rating_create.user_id)
        movie_exists = await movie_client.validate_movie(rating_create.movie_id)

        if not user_exists:
            raise HTTPException(status_code=404, detail="User does not exist")

        if not movie_exists:
            raise HTTPException(status_code=404, detail="Movie does not exist")
        
        new_rating = RatingTable(
            user_id=rating_create.user_id,
            movie_id=rating_create.movie_id,
            rating=rating_create.rating,
            review=rating_create.review,
            tag=rating_create.tag
        )

        db.add(new_rating)
        db.commit()
        db.refresh(new_rating)
        background_tasks.add_task(calculate_movie_avg, rating_create.movie_id, get_db)
        return new_rating
    except HTTPException:
        raise 
    except Exception as e:
        print(f"Error creating rating: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating rating")

@app.get("/ratings", response_model=List[Rating])
def get_ratings(
    user_id: Optional[int] = Query(None, description="Filter ratings by user ID"),
    movie_id: Optional[int] = Query(None, description="Filter ratings by movie ID"),
    min_rating: Optional[float] = Query(None, ge=1.0, le=5.0, description="Filter ratings with a minimum rating value"),
    max_rating: Optional[float] = Query(None, ge=1.0, le=5.0, description="Filter ratings with a maximum rating value"),
    db: Session = Depends(get_db)
):
    try:
        query = db.query(RatingTable).filter(RatingTable.is_quarantined == False)
        if user_id is not None:
            query = query.filter(RatingTable.user_id == user_id)
        if movie_id is not None:
            query = query.filter(RatingTable.movie_id == movie_id)
        if min_rating is not None:
            query = query.filter(RatingTable.rating >= min_rating)
        if max_rating is not None:
            query = query.filter(RatingTable.rating <= max_rating)
        
        return query.all()
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving ratings: {e}")
        raise HTTPException(status_code=500, detail=f"Error retrieving ratings:")

@app.get("/ratings/{rating_id}", response_model=Rating)
def get_rating(rating_id: int = Path(notnull=True, description="The ID of the rating to retrieve"), db: Session = Depends(get_db)):
    try:
        rating = db.query(RatingTable).filter(RatingTable.rating_id == rating_id, RatingTable.is_quarantined == False).first()
        if not rating:
            raise HTTPException(status_code=404, detail="Rating not found")
        return rating
    except HTTPException:
        raise 
    except Exception as e:
        print(f"Error retrieving rating: {e}")
        raise HTTPException(status_code=500, detail=f"Error retrieving rating")
    
@app.put("/ratings/{rating_id}")
def update_rating(
    rating_id: int = Path(description="The ID of the rating to update"), 
    rating_update: UpdateRating = None, 
    background_tasks: BackgroundTasks = None,
    db: Session = Depends(get_db)
):
    try:
        rating = db.query(RatingTable).filter(RatingTable.rating_id == rating_id, RatingTable.is_quarantined == False).first()
        if not rating:
            raise HTTPException(status_code=404, detail="Rating not found")
        
        # after user authentication, ensure only user owner of the rating can update it
        update_rating = rating_update.model_dump(exclude_unset=True)
        if not update_rating:
            raise HTTPException(status_code=422, detail="No fields provided for update")

        for field, value in update_rating.items():
            setattr(rating, field, value)
        
        rating.updated_at = datetime.now()
        
        db.commit()
        db.refresh(rating)
        background_tasks.add_task(calculate_movie_avg, rating.movie_id, get_db)
        return {"status_code": 200, "detail": "Rating updated successfully"}
    except HTTPException:
        raise 
    except Exception as e:
        print(f"Error updating rating: {e}")
        raise HTTPException(status_code=500, detail=f"Error updating rating")

@app.delete("/ratings/{rating_id}")
def delete_rating(
    rating_id: int = Path(description="The ID of the rating to delete"), 
    background_tasks: BackgroundTasks = None,
    db: Session = Depends(get_db)
):
    try:
        rating = db.query(RatingTable).filter(RatingTable.rating_id == rating_id, RatingTable.is_quarantined == False).first()
        if not rating:
            raise HTTPException(status_code=404, detail="Rating not found")
        
        # after user authentication, ensure only user owner of the rating can delete it
        db.delete(rating)
        db.commit()
        background_tasks.add_task(calculate_movie_avg, rating.movie_id, get_db)
        return {"status_code": 200, "detail": "Rating deleted successfully"}
    except HTTPException:
        raise 
    except Exception as e:
        print(f"Error deleting rating: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting rating")   

@app.post("/movies/{movie_id}/ratings", response_model=Rating, status_code=201)
def create_movie_rating(
    movie_id: int = Path(description="The ID of the movie being rated"),
    rating_create: MovieRating = None,
    db: Session = Depends(get_db)
):
    try:
        rating_data = RatingCreate(
            user_id=rating_create.user_id,
            movie_id=movie_id,
            rating=rating_create.rating,
            review=rating_create.review,
            tag=rating_create.tag
        )

        return create_rating(rating_data, db)

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating movie rating: {e}")
        raise HTTPException(status_code=500, detail="Error creating movie rating")   

@app.get("/movies/{movie_id}/ratings", response_model=List[Rating])
async def get_movie_ratings(
    movie_id: int = Path(description="The ID of the movie to retrieve ratings for"),
    user_id: Optional[int] = Query(None, description="Filter ratings by user ID"),
    min_rating: Optional[float] = Query(None, ge=1.0, le=5.0, description="Filter ratings with a minimum rating value"),
    max_rating: Optional[float] = Query(None, ge=1.0, le=5.0, description="Filter ratings with a maximum rating value"),
    tag: Optional[str] = Query(None, description="Filter ratings by tag"),
    movie_client: MovieGrpcClient = Depends(get_movie_client),
    db: Session = Depends(get_db)
):
    try:
        movie_exists = await movie_client.validate_movie(movie_id)

        if not movie_exists:
            raise HTTPException(status_code=404, detail="Movie does not exist")
        
        query = db.query(RatingTable).filter(RatingTable.is_quarantined == False)
        if user_id is not None:
            query = query.filter(RatingTable.user_id == user_id)
        if movie_id is not None:
            query = query.filter(RatingTable.movie_id == movie_id)
        if min_rating is not None:
            query = query.filter(RatingTable.rating >= min_rating)
        if max_rating is not None:
            query = query.filter(RatingTable.rating <= max_rating)
        if tag is not None:
            query = query.filter(RatingTable.tag.overlap(tag))
        
        if query.count() == 0:
            raise HTTPException(status_code=404, detail="No ratings found for the specified criteria")
        
        return query.all()
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error retrieving ratings: {e}")
        raise HTTPException(status_code=500, detail=f"Error retrieving ratings:")

@app.get("/users/{user_id}/ratings", response_model=List[Rating])
async def get_user_ratings(
    user_id: int = Path(description="The ID of the user to retrieve ratings for"),
    movie_id: Optional[int] = Query(None, description="Filter ratings by movie ID"),
    min_rating: Optional[float] = Query(None, ge=1.0, le=5.0, description="Filter ratings with a minimum rating value"),
    max_rating: Optional[float] = Query(None, ge=1.0, le=5.0, description="Filter ratings with a maximum rating value"),
    user_client: UserGrpcClient = Depends(get_user_client),
    db: Session = Depends(get_db)
):
    try:
        user_exists = await user_client.validate_user(user_id)

        if not user_exists:
            raise HTTPException(status_code=404, detail="User does not exist")
        
        query = db.query(RatingTable).filter(RatingTable.is_quarantined == False)
        if user_id is not None:
            query = query.filter(RatingTable.user_id == user_id)
        if movie_id is not None:
            query = query.filter(RatingTable.movie_id == movie_id)
        if min_rating is not None:
            query = query.filter(RatingTable.rating >= min_rating)
        if max_rating is not None:
            query = query.filter(RatingTable.rating <= max_rating)
        
        if query.count() == 0:
            raise HTTPException(status_code=404, detail="No ratings found for the specified criteria")
        
        return query.all()
    except HTTPException:
        raise
    except Exception as e:          
        print(f"Error retrieving ratings: {e}")
        raise HTTPException(status_code=500, detail=f"Error retrieving ratings:")

# occurs on background update of ratings
def calculate_movie_avg(movie_id: int, db_session_factory):
    db = next(db_session_factory())
    try: 
        query = db.query(func.avg(RatingTable.rating)).filter(RatingTable.movie_id == movie_id, RatingTable.is_quarantined == False).scalar()
        movie = db.query(Movie).filter(Movie.movie_id == movie_id).first() # later call grpc movie (needs some changes)

        if movie:
            movie.avg_rating = float(query) if query is not None else None
            db.commit()
        print(f' Recalculated average rating for movie {movie_id}: {movie.avg_rating}')
    except Exception as e:
        print(f'Unexpected error in avg recalculation task: {e}')
        db.rollback()
    finally:
        db.close()