from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey, Boolean, Float
from sqlalchemy.dialects.postgresql import ARRAY
from datetime import datetime
from dotenv import load_dotenv
import os


load_dotenv()
DB_URL = os.getenv("DB_URL_LOCAL")

engine = create_engine(DB_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class RatingTable(Base):
    __tablename__ = "ratings"

    ratingid = Column(Integer, primary_key=True, index=True)
    userid = Column(Integer, ForeignKey("users.userid"), nullable=False)
    movieid = Column(Integer, ForeignKey("movies.movieid"), nullable=False)
    rating = Column(Float, nullable=False)
    review = Column(String, nullable=True)
    createdat = Column(DateTime, default=datetime.now())
    updatedat = Column(DateTime, default=datetime.now(), onupdate=datetime.now())
    isquarantined = Column(Boolean, default=False) 
    tags = Column(ARRAY(String), default=[], nullable=True)

class User(Base):
    __tablename__ = "users"
    userid = Column(Integer, primary_key=True)

class Movie(Base):
    __tablename__ = "movies"
    movieid = Column(Integer, primary_key=True)
