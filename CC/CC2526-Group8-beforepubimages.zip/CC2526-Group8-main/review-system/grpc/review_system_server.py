import asyncio
from datetime import datetime, timezone
from google.protobuf.timestamp_pb2 import Timestamp
import grpc
import rating_pb2, rating_pb2_grpc
from dotenv import load_dotenv
import os
import httpx


load_dotenv()
REST_URL = os.getenv("REST_URL")
GRPC_PORT = int(os.getenv("GRPC_PORT"))

def _ts(value):
    ts = Timestamp()

    if not value:  
        return ts

    # convert date_str -> datetime
    if isinstance(value, str):
        v = value.replace(" ", "T")
        if v.endswith("Z"):
            v = v[:-1] + "+00:00"
        value = datetime.fromisoformat(v)

    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)

    ts.FromDatetime(value)
    return ts

class ReviewService(rating_pb2_grpc.ReviewServiceServicer):
    def __init__(self):
        self._lock = asyncio.Lock()
        self._client = httpx.AsyncClient()

    async def GetRatings(self, request, context):
        parameters = {}
        url = f"{REST_URL}/ratings"
        
        if request.movie_id:
            parameters['movie_id'] = request.movie_id
        if request.user_id:
            parameters['user_id'] = request.user_id
        if request.min_rating:
            parameters['min_rating'] = request.min_rating
        if request.max_rating:
            parameters['max_rating'] = request.max_rating
        
        async with self._lock:
            resp = await self._client.get(url, params=parameters)

        if resp.status_code != 200:
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Failed to fetch movieratings: {resp.text}")
            return rating_pb2.GetRatingsResponse()

        rows = resp.json()
        out = rating_pb2.GetRatingsResponse()

        for r in rows:
            msg = out.ratings.add()
            msg.rating_id = r['rating_id']
            msg.user_id = r['user_id']
            msg.movie_id = r['movie_id']
            msg.rating = float(r['rating'])
            msg.review = r["review"] or ""
            msg.tag = r["tag"] or ""
            msg.created_at.CopyFrom(_ts(r['created_at']))
            msg.updated_at.CopyFrom(_ts(r['updated_at']))

        return out
    
    async def GetMovieRatings(self, request, context):
        url = f"{REST_URL}/movies/{request.movie_id}/ratings"
        async with self._lock:
            resp = await self._client.get(url)

        if resp.status_code != 200:
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Failed to fetch movieratings: {resp.text}")
            return rating_pb2.GetRatingsResponse()

        rows = resp.json()
        out = rating_pb2.GetRatingsResponse()

        for r in rows:
            msg = out.ratings.add()
            msg.rating_id = r['rating_id']
            msg.user_id = r['user_id']
            msg.movie_id = r['movie_id']
            msg.rating = float(r['rating'])
            msg.review = r["review"] or ""
            msg.tag = r["tag"] or ""
            msg.created_at.CopyFrom(_ts(r['created_at']))
            msg.updated_at.CopyFrom(_ts(r['updated_at']))

        return out

    async def GetUserRatings(self, request, context):
        url = f"{REST_URL}/users/{request.user_id}/ratings"
        async with self._lock:
            resp = await self._client.get(url)

        if resp.status_code != 200:
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Failed to fetch ratings: {resp.text}")
            return rating_pb2.GetRatingsResponse()

        rows = resp.json()
        out = rating_pb2.GetRatingsResponse()
        
        for r in rows:
            msg = out.ratings.add()
            msg.rating_id = r['rating_id']
            msg.user_id = r['user_id']
            msg.movie_id = r['movie_id']
            msg.rating = float(r['rating'])
            msg.review = r["review"] or ""
            msg.tag = r["tag"] or ""
            msg.created_at.CopyFrom(_ts(r['created_at']))
            msg.updated_at.CopyFrom(_ts(r['updated_at']))

        return out
    
async def serve(host="0.0.0.0", port=GRPC_PORT):
    server = grpc.aio.server(options=[
        ("grpc.keepalive_time_ms", 30_000),
        ("grpc.keepalive_timeout_ms", 10_000),
    ])
    rating_pb2_grpc.add_ReviewServiceServicer_to_server(ReviewService(), server)
    server.add_insecure_port(f"{host}:{port}")
    await server.start()
    print(f"Review gRPC server running on {host}:{port}")
    await server.wait_for_termination()

if __name__ == "__main__":
    asyncio.run(serve())
