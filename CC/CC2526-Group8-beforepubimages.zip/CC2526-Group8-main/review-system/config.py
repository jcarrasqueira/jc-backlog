from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import create_engine, Column, ForeignKey,Integer, String, DateTime,  Boolean, Float, Text
from users.users_client import UserGrpcClient
from movies.movies_client import MovieGrpcClient
from datetime import datetime
from dotenv import load_dotenv
import os


load_dotenv()
DB_URL = os.getenv("DB_URL")
USERS_GRPC_URL = os.getenv("USERS_GRPC_URL")
MOVIES_GRPC_URL = os.getenv("MOVIES_GRPC_URL")

engine = create_engine(DB_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

user_client = UserGrpcClient(target=USERS_GRPC_URL)
movie_client = MovieGrpcClient(target=MOVIES_GRPC_URL)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class RatingTable(Base):
    __tablename__ = "ratings"

    rating_id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False)
    movie_id = Column(Integer, nullable=False)
    rating = Column(Float, nullable=False)
    review = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.now())
    updated_at = Column(DateTime, default=datetime.now(), onupdate=datetime.now())
    is_quarantined = Column(Boolean, default=False) 
    tag = Column(Text, nullable=True)